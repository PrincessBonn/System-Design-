from tkinter import *
from tkinter import messagebox
import common


root = Tk()
root.geometry("1000x700")
root.title('Library Search')

select_answer = StringVar(root)
enter_answer = StringVar(root)
location = StringVar(root)

def change_input(event):
    
    label_2.place(x=100, y=130)
    button_2.place(x=100, y=230, width=400, height=50)
    if select_answer.get() == 'Location':
        select_location.place(x=100, y=160, width=400, height=50)
        input_area.place_forget()
        label_2.config(text="Select " + str(select_answer.get()) + ": ")
    else:
        input_area.place(x=100, y=160, width=400, height=50)
        select_location.place_forget()
        label_2.config(text="Enter the " + str(select_answer.get()) + ": ")
   

def part_2_phase_2():

    if select_answer.get()  == 'Location'  and location.get():
        result = common.get_result(
            location.get(), select_answer.get())

    else:# select_answer.get() and enter_answer.get():

        result = common.get_result(
            enter_answer.get(), select_answer.get())


    # label_3 = Label(root, text="OUTPUT:".center(100))
    # label_3.place(x=100, y=250)

    # label_4 = Label(root, text="")
    # label_4.place(x=100, y=270)

    if result != "":
        messagebox.showinfo(messagebox.INFO, str(result))
    else:
        messagebox.showinfo(messagebox.INFO, str("Unable to get result"))



label_1 = Label(root, text="Select one of the below options: ")
label_1.place(x=100, y=50)

select_area = OptionMenu(root, select_answer, *[
                         "Location", "Subject", "Classmark"], command = change_input)
select_area.place(x=100, y=80, width=400)

label_2 = Label(root, text="")
input_area = Entry(root, width=54, textvariable=enter_answer)
button_2 = Button(root, text="Submit", command=part_2_phase_2)

select_location = OptionMenu(root, location, *common.locations())

root.mainloop()