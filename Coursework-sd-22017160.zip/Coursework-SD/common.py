import csv

csv_1_path = "csv-1.csv"
csv_2_path = "csv-2.csv"


def read_csv(file):
    with open(file, newline='') as file_content:
        return list(csv.reader(file_content))

def locations():
    location =[]
    for loca in read_csv(csv_1_path):
        if loca[1] not in location:
            location.append(loca[1])
    return location


def get_location_from_csv(value):
    csv_content = read_csv(csv_1_path)
    for row in csv_content:
        if str(row[0]) == value.upper():
            return row[1]

    return ""


def get_subject_from_csv(value):
    csv_content = read_csv(csv_2_path)
    for row in csv_content:
        if str(row[0]) == value.upper():
            row.pop(0)
            return ", ".join(row)

    return ""


def find_subject(entered_subject):
    subjects = ""

    csv_content = read_csv(csv_2_path)
    for row in csv_content:
        for i in range(len(row)):
           # if i != 0 and row[i].lower() == entered_subject:
            if i != 0 and entered_subject in row[i].lower():
                subjects = subjects + \
                    "Subject => " + row[i] + \
                    " | Location => " + get_location_from_csv(row[0]) + \
                    " | Classmark => " + row[0] + "\n\n"
                break
    return subjects


def find_location(entered_location):
    locations = ""

    csv_content = read_csv(csv_1_path)
    for row in csv_content:
        for i in range(len(row)):
           # if i != 0 and row[i].lower() == entered_location:
            if i != 0 and entered_location in row[i].lower():
                locations = locations + \
                    "Location => " + row[i] + \
                    " | Subjects => " + get_subject_from_csv(row[0]) + \
                    " | Classmark => " + row[0] + "\n\n"
                break
    return locations


def find_classmark(entered_classmark):
    classmarks = ""

    csv_content = read_csv(csv_2_path)
    for row in csv_content:
        for i in range(len(row)):
            if entered_classmark in  row[i].lower():
                classmarks = classmarks + \
                    "Classmark => " + row[0] + \
                    " | Location => " + get_location_from_csv(row[0]) + \
                    " | Subjects => " + get_subject_from_csv(row[0]) + "\n\n"
                break
    return classmarks


def get_result(entered_answer, entered_option):
    if entered_option.lower() == "subject":
        return find_subject(entered_answer.strip().lower())
    elif entered_option.lower() == "location":
        return find_location(entered_answer.strip().lower())
    elif entered_option.lower() == "classmark":
        return find_classmark(entered_answer.strip().lower())
    else:
        return "Unable to process input"
