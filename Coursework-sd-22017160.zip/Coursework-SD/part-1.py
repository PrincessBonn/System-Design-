import common

def print_locations():
    selected = ''
    print('\nSelect a location below: \n(A) Top Floor Front Left\n', '(B) Top Floor Front Right\n', '(C) Top Floor Back Left\n', '(D) Middle Floor\n', '(E) Top Floor Back Right\n', '(F) Ground Floor')
    selected_location = input()
    if selected_location.upper() == 'A':
        selected = 'Top Floor Front Left'
    elif selected_location.upper() == 'B':
        selected = 'Top Floor Front Right'
    elif selected_location.upper() == 'C':
        selected = 'Top Floor Back Left'
    elif selected_location.upper() == 'D':
        selected = 'Middle Floor'
    elif selected_location.upper() == 'E':
        selected = 'Top Floor Back Right'
    elif selected_location.upper() == 'F':
        selected = 'Ground Floor'
    else:
        selected = 'Incorrect Selection. Try again'
    print('You chose: ' + selected)
    return selected

def part_1():
    print("Select one of the below options: ")
    print("(A) Location ")
    print("(B) Classmark ")
    print("(C) Subject ")

    answer = input("Pick either A, B or C: ")
    selected_option = ""
    is_answer_correct = False
    if answer.upper() == 'A':
        selected_option = "location"
        is_answer_correct = True
        print("You chose: Location")
    elif answer.upper() == 'B':
        selected_option = "classmark"
        is_answer_correct = True
        print("You chose: Classmark")
    elif answer.upper() == 'C':
        selected_option = "subject"
        is_answer_correct = True
        print("You chose: Subject")
    else:
        print("Incorrect selection. Try again")

    if is_answer_correct:
        if selected_option == 'location':
            print(common.get_result(print_locations(), selected_option))

        else:
            second_answer = input(
                "Enter the value for "+str(selected_option) + ": ")

            print(common.get_result(second_answer, selected_option))

    else:
        print("Try again")


part_1()
